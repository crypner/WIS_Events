<?php
get_header();
?>
<main class="container">
	<div class="row d-flex justify-content-center">
		<img src='<?php echo get_template_directory_uri(); ?>/img/404.jpg' alt="Not Found" style="max-width: 600px;" />
	</div>
</main>
<?php
get_footer();
?>